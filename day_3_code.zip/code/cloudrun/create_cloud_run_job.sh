export PROJECT_ID=test-app-309909
export IMAGE=simple-image
export TAG=v1.0
export JOB_NAME=simple-job 
export SERVICE_ACCOUNT=batch-job-service-account@test-app-309909.iam.gserviceaccount.com

gcloud run jobs create ${JOB_NAME} \
            --region asia-east1 \
            --image gcr.io/${PROJECT_ID}/${IMAGE}:${TAG} \
            --service-account ${SERVICE_ACCOUNT}