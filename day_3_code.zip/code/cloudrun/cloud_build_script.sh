export PROJECT_ID=test-app-309909
export IMAGE=simple-image
export TAG=v1.0

gcloud builds submit --config=cloudbuild.yaml \
                    --substitutions=_PROJECT_ID=${PROJECT_ID},_IMAGE_NAME=${IMAGE},_TAG=${TAG}